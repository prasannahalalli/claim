package com.claimswift.controller;

import com.claimswift.dto.LoginRequest;
import com.claimswift.model.User;
import com.claimswift.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {

        if (loginRequest.getEmail() == null || loginRequest.getPassword() == null || loginRequest.getRole() == null) {
            return ResponseEntity.badRequest().body("Email, Password, and Role are mandatory");
        }

        String result = authService.login(
                loginRequest.getEmail(),
                loginRequest.getPassword(),
                loginRequest.getRole()
        );

        switch (result) {
            case "SUCCESS":
                User user = authService.findUserByEmail(loginRequest.getEmail());
                return ResponseEntity.ok(Map.of(
                        "message", "Login Successful",
                        "user", user
                ));

            case "INVALID_CREDENTIALS":
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("message", "Invalid Email or Password"));

            case "ROLE_MISMATCH":
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                        .body(Map.of("message", "Role does not match account"));

            case "NO_INSURANCE":
                return ResponseEntity.status(HttpStatus.FORBIDDEN)
                        .body(Map.of(
                                "message", "Access Denied",
                                "reason", "You do not have an active ClaimSwift Insurance policy."
                        ));

            default:
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body(Map.of("message", "Unexpected Error"));
        }
    }
}
