package com.claimswift.dto;

public class ClaimPartDTO {
    private String partName;
    private Double amount;
    
    // Constructors
    public ClaimPartDTO() {}
    
    public ClaimPartDTO(String partName, Double amount) {
        this.partName = partName;
        this.amount = amount;
    }
    
    // Getters and Setters
    public String getPartName() {
        return partName;
    }
    
    public void setPartName(String partName) {
        this.partName = partName;
    }
    
    public Double getAmount() {
        return amount;
    }
    
    public void setAmount(Double amount) {
        this.amount = amount;
    }
}