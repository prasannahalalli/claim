package com.claimswift.model;

public enum ClaimStatus {
    PENDING,
    APPROVED,
    DISAPPROVED
}