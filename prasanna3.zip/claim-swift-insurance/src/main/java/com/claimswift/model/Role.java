package com.claimswift.model;

public enum Role {
    USER,
    AGENT
}